import onnxruntime
import cv2
import numpy as np
import torch
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
import matplotlib.pyplot as plt
from ultralytics.utils import ops

kpts_shape = [5, 2]

ort_session = onnxruntime.InferenceSession('../best.onnx', provider='CPUExecutionProvider')
model_input = ort_session.get_inputs()  # 输入层的名字和形状
input_name = [model_input[0].name]
input_shape = model_input[0].shape
input_height, input_width = input_shape[2:]
model_output = ort_session.get_outputs()  # 输出层的名字和形状
output_name = [model_output[0].name]
output_shape = model_output[0].shape

img_path = '../src/red_img.jpg'
img_bgr = cv2.imread(img_path)
img_bgr_640 = cv2.resize(img_bgr, [input_height, input_width])  # 缩放到网络输入尺寸 640x640
img_rgb_640 = img_bgr_640[:,:,::-1]

plt.imshow(img_rgb_640)
plt.show()

# X 方向 图像缩放比例
x_ratio = img_bgr.shape[1] / input_width
# Y 方向 图像缩放比例
y_ratio = img_bgr.shape[0] / input_height

# 预处理-归一化
input_tensor = img_rgb_640 / 255
# 预处理-构造输入 Tensor
input_tensor = np.expand_dims(input_tensor, axis=0) # 加 batch 维度
input_tensor = input_tensor.transpose((0, 3, 1, 2)) # N, C, H, W
input_tensor = np.ascontiguousarray(input_tensor)   # 将内存不连续存储的数组，转换为内存连续存储的数组，使得内存访问速度更快
input_tensor = torch.from_numpy(input_tensor).to(device).float() # 转 Pytorch Tensor
# input_tensor = input_tensor.half() # 是否开启半精度，即 uint8 转 fp16，默认转 fp32

# input_numpy = np.expand_dims(np.transpose(img_rgb_640, (2, 0, 1)), 0).astype(np.float32)  # 对比两种转换方式，从而知道自己在openvino中的错误

# ONNX Runtime 推理预测
ort_output = ort_session.run(output_name, {input_name[0]: input_tensor.numpy()})[0]
# ort_output = ort_session.run(output_name, {input_name[0]: input_numpy})[0]
# 转 Tensor
preds = torch.Tensor(ort_output)

# 后处理
preds = ops.non_max_suppression(preds, conf_thres=0.9, iou_thres=0.9, nc=6)
pred = preds[0]

pred_det = pred[:, :6].cpu().numpy()
num_bbox = len(pred_det)
print('预测出 {} 个框'.format(num_bbox))
# 类别
bboxes_cls = pred_det[:, 5]
# 置信度
bboxes_conf = pred_det[:, 4]
# 框坐标
# 目标检测框 XYXY 坐标
# 还原为缩放之前原图上的坐标
pred_det[:, 0] = pred_det[:, 0] * x_ratio
pred_det[:, 1] = pred_det[:, 1] * y_ratio
pred_det[:, 2] = pred_det[:, 2] * x_ratio
pred_det[:, 3] = pred_det[:, 3] * y_ratio
bboxes_xyxy = pred_det[:, :4].astype('uint32')

pred_kpts = pred[:, 6:].view(len(pred), kpts_shape[0], kpts_shape[1])
bboxes_keypoints = pred_kpts.cpu().numpy()
# 还原为缩放之前原图上的坐标
bboxes_keypoints[:,:,0] = bboxes_keypoints[:,:,0] * x_ratio
bboxes_keypoints[:,:,1] = bboxes_keypoints[:,:,1] * y_ratio
bboxes_keypoints = bboxes_keypoints.astype('uint32')

# 框（rectangle）可视化配置
bbox_color = (150, 0, 0)             # 框的 BGR 颜色
bbox_thickness = 6                   # 框的线宽

# 框类别文字
bbox_labelstr = {
    'font_size':4,         # 字体大小
    'font_thickness':10,   # 字体粗细
    'offset_x':0,          # X 方向，文字偏移距离，向右为正
    'offset_y':-80,        # Y 方向，文字偏移距离，向下为正
}

# 关键点 BGR 配色
kpt_color_map = {
    0:{'name':'', 'color':[255, 0, 0], 'radius':10},
    1:{'name':'', 'color':[0, 255, 0], 'radius':10},
    2:{'name':'', 'color':[0, 0, 255], 'radius':10},
    3:{'name':'', 'color':[255, 255, 0], 'radius':10},
    4:{'name':'', 'color':[255, 0, 255], 'radius':10},
}

# 点类别文字
kpt_labelstr = {
    'font_size':4,             # 字体大小
    'font_thickness':10,       # 字体粗细
    'offset_x':30,             # X 方向，文字偏移距离，向右为正
    'offset_y':120,            # Y 方向，文字偏移距离，向下为正
}
for idx in range(num_bbox):  # 遍历每个框

    # 获取该框坐标
    bbox_xyxy = bboxes_xyxy[idx]

    # 获取框的预测类别（对于关键点检测，只有一个类别）
    bbox_label = str(int(bboxes_cls[idx]))

    # 画框
    img_bgr = cv2.rectangle(img_bgr, (bbox_xyxy[0], bbox_xyxy[1]), (bbox_xyxy[2], bbox_xyxy[3]), bbox_color,
                            bbox_thickness)

    # 写框类别文字：图片，文字字符串，文字左上角坐标，字体，字体大小，颜色，字体粗细
    img_bgr = cv2.putText(img_bgr, bbox_label,
                          (bbox_xyxy[0] + bbox_labelstr['offset_x'], bbox_xyxy[1] + bbox_labelstr['offset_y']),
                          cv2.FONT_HERSHEY_SIMPLEX, bbox_labelstr['font_size'], bbox_color,
                          bbox_labelstr['font_thickness'])

    bbox_keypoints = bboxes_keypoints[idx]  # 该框所有关键点坐标和置信度

    # 画该框的关键点
    for kpt_id in kpt_color_map:
        # 获取该关键点的颜色、半径、XY坐标
        kpt_color = kpt_color_map[kpt_id]['color']
        kpt_radius = kpt_color_map[kpt_id]['radius']
        kpt_x = bbox_keypoints[kpt_id][0]
        kpt_y = bbox_keypoints[kpt_id][1]

        # 画圆：图片、XY坐标、半径、颜色、线宽（-1为填充）
        img_bgr = cv2.circle(img_bgr, (kpt_x, kpt_y), kpt_radius, kpt_color, -1)

        # 写关键点类别文字：图片，文字字符串，文字左上角坐标，字体，字体大小，颜色，字体粗细
        # kpt_label = str(kpt_id) # 写关键点类别 ID
        kpt_label = str(kpt_color_map[kpt_id]['name'])  # 写关键点类别名称
        img_bgr = cv2.putText(img_bgr, kpt_label, (kpt_x + kpt_labelstr['offset_x'], kpt_y + kpt_labelstr['offset_y']),
                              cv2.FONT_HERSHEY_SIMPLEX, kpt_labelstr['font_size'], kpt_color,
                              kpt_labelstr['font_thickness'])

plt.imshow(img_bgr[:,:,::-1])
plt.show()
cv2.imwrite('./red_img_infer_onnx.jpg', img_bgr)
