# 这个文件其实相当于是吧infer_openvino.py完全搬过来了，我并没有另外做一个类来做这个。
import cv2
from openvino.runtime import Core
from ultralytics.utils import ops
import cv2
import time
import numpy as np
import torch
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

core = Core()
detection_model_xml = "../best_openvino_model/best.xml"

model = core.read_model(model=detection_model_xml)
compiled_model = core.compile_model(model=model, device_name="GPU")

input_layer = model.input(0)  # 不过根据我的观察model.input和model.output都是在这里是一样的
output_layer = model.output(0)
# 我原本是这么认为的，但是做了下面的输出后发现不是这样
# print(model.input(0))  # <Output: names[images] shape[1,3,640,640] type: f32>
# print(model.output(0))  # <Output: names[output0] shape[1,20,8400] type: f32>

# 原先的视频找不到了，用被预测过的视频替代一下，效果肯定会差一些，但主要是走个模型部署的流程
video_path = '/home/zhaocake/Downloads/test_video.mp4'
cap = cv2.VideoCapture(video_path)

# 创建视频写入器，指定mp4v
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
# 获取视频帧率
fps = cap.get(cv2.CAP_PROP_FPS)
# 获取视频宽高
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
# 创建视频写入器
out = cv2.VideoWriter('output.mp4', fourcc, fps, (width, height))

while True:
    ret, image = cap.read()
    if ret:
        start_time = time.time()
        # N,C,H,W = batch size, number of channels, height, width.
        N, C, H, W = input_layer.shape
        # OpenCV resize expects the destination size as (width, height).
        resized_image = cv2.resize(src=image, dsize=(W, H))
        # # 这仍然是HWC格式，必须更改为NCHW格式，并且顺便把数据类型转换为f32
        # input_data = np.expand_dims(np.transpose(resized_image, (2, 0, 1)), 0).astype(np.float32)  # 从onnx的过程来看，错因是没有预处理
        img_rgb_640 = resized_image[:, :, ::-1]

        # 预处理-归一化
        input_tensor = img_rgb_640 / 255
        # 预处理-构造输入 Tensor
        input_tensor = np.expand_dims(input_tensor, axis=0)  # 加 batch 维度
        input_tensor = input_tensor.transpose((0, 3, 1, 2))  # N, C, H, W
        input_tensor = np.ascontiguousarray(input_tensor)  # 将内存不连续存储的数组，转换为内存连续存储的数组，使得内存访问速度更快
        input_tensor = torch.from_numpy(input_tensor).to(device).float()  # 转 Pytorch Tensor
        # input_tensor = input_tensor.half() # 是否开启半精度，即 uint8 转 fp16，默认转 fp32

        x_ratio = image.shape[1] / resized_image.shape[1]
        y_ratio = image.shape[0] / resized_image.shape[0]
        request = compiled_model.create_infer_request()
        outputs = request.infer(inputs={input_layer.any_name: input_tensor.numpy()})
        outputs = torch.Tensor(outputs[output_layer.any_name])
        print(outputs.shape)

        # 我一直找不到对于如何处理openvino部署关键点检测outputs的文档，后来我想起来openvino比起onnx来说还不够繁荣，所以我去看了onnx的资料，终于理解了。
        # 同时我也理解了这一步同样是在模型转换之前的用yolo中推理一直都在做的，只是用多了命令行，调包多了，就不再注意这些了。到目前为止已经收获颇丰。
        # 不过下面又出现了一些状况，所以最后其实还是学习的yolo的源码，因为这些不会的都是后处理。

        preds = ops.non_max_suppression(outputs, conf_thres=0.7, iou_thres=0.7, nc=6)
        pred = preds[0]
        pred_det = pred[:, :6].cpu().numpy()
        print(pred_det)
        bboxes_cls = pred_det[:, 5]
        bboxes_conf = pred_det[:, 4]
        # 目标检测框 XYXY 坐标
        # 还原为缩放之前原图上的坐标
        pred_det[:, 0] = pred_det[:, 0] * x_ratio
        pred_det[:, 1] = pred_det[:, 1] * y_ratio
        pred_det[:, 2] = pred_det[:, 2] * x_ratio
        pred_det[:, 3] = pred_det[:, 3] * y_ratio

        bboxes_xyxy = pred_det[:, :4].astype('uint32')

        num_bbox = len(pred_det)
        print('预测出 {} 个框'.format(num_bbox))
        kpts_shape = [5, 2]
        pred_kpts = pred[:, 6:].view(len(pred), kpts_shape[0], kpts_shape[1])
        bboxes_keypoints = pred_kpts.cpu().numpy()
        # 还原为缩放之前原图上的坐标
        bboxes_keypoints[:, :, 0] = bboxes_keypoints[:, :, 0] * x_ratio
        bboxes_keypoints[:, :, 1] = bboxes_keypoints[:, :, 1] * y_ratio
        bboxes_keypoints = bboxes_keypoints.astype('uint32')

        # 画框
        # 框（rectangle）可视化配置
        bbox_color = (123, 222, 0)  # 框的 BGR 颜色
        bbox_thickness = 6  # 框的线宽

        # 框类别文字
        bbox_labelstr = {
            'font_size': 0.8,  # 字体大小
            'font_thickness': 3,  # 字体粗细
            'offset_x': 0,  # X 方向，文字偏移距离，向右为正
            'offset_y': -20,  # Y 方向，文字偏移距离，向下为正
        }

        # 关键点 BGR 配色
        kpt_color_map = {
            0: {'name': '', 'color': [255, 0, 0], 'radius': 10},
            1: {'name': '', 'color': [0, 255, 0], 'radius': 10},
            2: {'name': '', 'color': [0, 0, 255], 'radius': 10},
            3: {'name': '', 'color': [255, 255, 0], 'radius': 10},
            4: {'name': '', 'color': [255, 0, 255], 'radius': 10},
        }

        # # 点类别文字
        # kpt_labelstr = {
        #     'font_size':2,             # 字体大小
        #     'font_thickness':5,       # 字体粗细
        #     'offset_x':30,             # X 方向，文字偏移距离，向右为正
        #     'offset_y':120,            # Y 方向，文字偏移距离，向下为正
        # }

        bbox_name_dict = {0: 'blue_heart', 1: 'blue_hitting', 2: 'blue_hitted', 3: 'red_heart', 4: 'red_hitting',
                          5: 'red_hitted'}

        for idx in range(num_bbox):  # 遍历每个框

            # 获取该框坐标
            bbox_xyxy = bboxes_xyxy[idx]

            # 获取框的预测类别（对于关键点检测，只有一个类别）
            bbox_label = bbox_name_dict[int(bboxes_cls[idx])] + ' ' + str(round(bboxes_conf[idx], 2))

            # 画框
            image = cv2.rectangle(image, (bbox_xyxy[0], bbox_xyxy[1]), (bbox_xyxy[2], bbox_xyxy[3]), bbox_color,
                                  bbox_thickness)

            # 写框类别文字：图片，文字字符串，文字左上角坐标，字体，字体大小，颜色，字体粗细
            image = cv2.putText(image, bbox_label,
                                (bbox_xyxy[0] + bbox_labelstr['offset_x'], bbox_xyxy[1] + bbox_labelstr['offset_y']),
                                cv2.FONT_HERSHEY_SIMPLEX, bbox_labelstr['font_size'], bbox_color,
                                bbox_labelstr['font_thickness'])

            bbox_keypoints = bboxes_keypoints[idx]  # 该框所有关键点坐标和置信度

            # 画该框的关键点
            for kpt_id in kpt_color_map:
                # 获取该关键点的颜色、半径、XY坐标
                kpt_color = kpt_color_map[kpt_id]['color']
                kpt_radius = kpt_color_map[kpt_id]['radius']
                kpt_x = bbox_keypoints[kpt_id][0]
                kpt_y = bbox_keypoints[kpt_id][1]

                # 画圆：图片、XY坐标、半径、颜色、线宽（-1为填充）
                image = cv2.circle(image, (kpt_x, kpt_y), kpt_radius, kpt_color, -1)
        end_time = time.time()
        delta_time = end_time - start_time
        infer_fps = 1 / delta_time
        cv2.putText(image, 'FPS: {:.2f}'.format(infer_fps), (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        out.write(image)  # 写入视频
        # 写入视频
        # cv2.imshow('image', image)
        # cv2.waitKey(30)
    else:
        print('视频结束，保存')
        break

cap.release()
out.release()

cv2.destroyAllWindows()




