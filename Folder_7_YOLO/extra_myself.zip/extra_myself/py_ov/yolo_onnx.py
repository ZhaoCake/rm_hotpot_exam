from ultralytics import YOLO

model = YOLO("../best.onnx", task='pose')

result = model.predict("../src/bule_img.jpg", task='pose', save=True)

# 结果已经放在当前目录下了